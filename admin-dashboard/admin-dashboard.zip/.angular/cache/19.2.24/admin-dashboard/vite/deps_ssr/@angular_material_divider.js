import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MatDivider,
  MatDividerModule
} from "./chunk-T2P4AANF.js";
import "./chunk-C5HDTQAM.js";
import "./chunk-DFRP7S3U.js";
import "./chunk-ZDK3SB4M.js";
import "./chunk-5E4GKLTA.js";
import "./chunk-4Z57NH77.js";
import "./chunk-B3KUK54O.js";
import "./chunk-2CXOXQWB.js";
import "./chunk-OMV6HQGA.js";
import "./chunk-ZUJ64LXG.js";
import "./chunk-XCIYP5SE.js";
import "./chunk-OYTRG5F6.js";
import "./chunk-YHCV7DAQ.js";
export {
  MatDivider,
  MatDividerModule
};
